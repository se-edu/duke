package duke.ui;

public interface Stoppable {
    public void stop() throws Exception;
}
